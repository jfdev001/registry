from mod.plot_registry import PlotRegistry
class Parser:
    def __init__(self):
        print(PlotRegistry.registry)
        return
