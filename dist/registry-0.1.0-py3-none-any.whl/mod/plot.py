from mod.plot_registry import PlotRegistry

@PlotRegistry.register
class ContourPlot:
    pass 
