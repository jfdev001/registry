# this calls the register function and populates the registry
import mod.plot 

# TODO: here get the .register path, read it, and import modules
# appropriately
